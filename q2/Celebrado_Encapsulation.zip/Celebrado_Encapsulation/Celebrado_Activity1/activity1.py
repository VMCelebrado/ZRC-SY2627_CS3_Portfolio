class GameCharacter:
    def __init__(self):
        self.username = ""


class BankAccount:
    def __init__(self):
        self.__balance = 0


class Vehicle:
    def __init__(self):
        self._engineCode = ""


class Student:
    def __init__(self):
        self.schoolName = ""


class VotingSystem:
    def __init__(self):
        self.__voterID = ""



character = GameCharacter()
account = BankAccount()
vehicle = Vehicle()
student = Student()
voting = VotingSystem()