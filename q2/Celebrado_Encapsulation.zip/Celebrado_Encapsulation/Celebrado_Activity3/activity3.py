class BankAccount:
    def __init__(self, account_number = int, balance = float):
        self.__account_number = account_number
        self.__balance = balance

    def set_account_number(self, account_number):
        self.__account_number = account_number

    def set_balance(self, balance):
        if balance < 0:
            print("WARNING: Balance cannot be negative. Setting balance to 0.")
            self.__balance = 0
        else:
            self.__balance = balance

    @property
    def get_account_number(self):
        return self.__account_number
    
    @property
    def get_balance(self):
        return self.__balance

account = BankAccount(123456, 1000.00)

print("Account Number:", account.get_account_number)
print(f"Balance: ₱{account.get_balance:,.2f}")

account.set_account_number(987654321)
account.set_balance(7500.50)

print("\nUpdated Account Information")
print("Account Number:", account.get_account_number)
print(f"Balance: ₱{account.get_balance:,.2f}")

account.set_balance(-1000)
