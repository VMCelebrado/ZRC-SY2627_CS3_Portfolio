class Rectangle:
    def __init__(self, width, height):
        self.__width = width
        self.__height = height

    @property
    def width(self):
        return self.__width

    @width.setter
    def width(self, width_value):
        if width_value < 0:
            print("Width must be a non-negative value.")
        self.__width = width_value

    @width.deleter
    def width(self):
        del self.__width
        print("Width has been deleted.")

    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, height_value):
        if height_value < 0:
            print("Height must be a non-negative value.")
        self.__height = height_value

    @height.deleter
    def height(self):
        del self.__height
        print("Height has been deleted.")


rectangle = Rectangle(10, 5)

print(rectangle.width)
print(rectangle.height)

rectangle.width = 20
rectangle.height = 15

print(rectangle.width) #Test subject for del rectangle.width
print(rectangle.height) #Test subject for del rectangle.height

del rectangle.width
del rectangle.height