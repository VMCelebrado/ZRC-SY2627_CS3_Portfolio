
class Parent:
    def __init__(self, message):
        self.message = message

    def get_message(self):
        return self.message

    def set_message(self, message):
        self.message = message

    def func1(self):
        print("This function is in parent class.")
        print("Message:", self.message)


class Child1(Parent):
    def func2(self):
        print("This function is in child 1.")


class Child2(Parent):
    def func3(self):
        print("This function is in child 2.")


object1 = Child1("Message for Child 1")
object2 = Child2("Message for Child 2")

object1.func1()
object1.func2()

print()

object2.func1()
object2.func3()

object1.set_message("Updated Child 1 message")
object2.set_message("Updated Child 2 message")

print("\nAfter updating messages:")
print(object1.get_message())
print(object2.get_message())

object3 = Child1("A new Child 1 object")
print("\nThird object:")
object3.func1()
object3.func2()
