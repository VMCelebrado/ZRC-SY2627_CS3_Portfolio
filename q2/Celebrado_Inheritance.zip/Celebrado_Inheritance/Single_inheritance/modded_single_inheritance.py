class Parent:
    def __init__(self, message):
        self.message = message

    def get_message(self):
        return self.message

    def set_message(self, message):
        self.message = message

    def func1(self):
        print("This function is in parent class.")
        print("Message:", self.message)


class Child(Parent):
    def func2(self):
        print("This function is in child class.")


obj = Child("Hello!")
obj.func1()
obj.func2()

obj.set_message("Inheritance is useful!")
print("Updated message:", obj.get_message())

obj2 = Child("Second object")
obj2.func1()
obj2.func2()
